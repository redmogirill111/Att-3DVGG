import os
import cv2
import numpy as np

# 此处坐标手动查找标志点的坐标、设置融合率
pts_rgb = np.array([[195, 699], [1679, 762], [826, 341], [1016, 353], [964, 212], [178, 298], [1616, 195], [1177, 90]])
pts_nir = np.array([[247, 687], [1740, 759], [886, 331], [1078, 344], [1034, 202], [243, 284], [1688, 190], [1249, 79]])
ronghelv = 0.5

mp4_rgb = r"/media/thhicv/新加卷/dataset/红外和可见光的火焰数据集/2022年3月13日一期采集/alarm/第一次配准/CCD/"
mp4_nir = r"/media/thhicv/新加卷/dataset/红外和可见光的火焰数据集/2022年3月13日一期采集/alarm/第一次配准/NIR/"
mp4_des = "/home/thhicv/program/data/近红外和可见光/第一次配准结果/"

# fourcc = cv2.VideoWriter_fourcc('M', 'P', '4', 'V')
fourcc = cv2.VideoWriter_fourcc(*'mp4v')

if not os.path.exists(mp4_des):
    os.makedirs(mp4_des)
for root, dirs, files in os.walk(mp4_rgb):
    j = 1
    for file in files:
        print("the file '", file, "' is read ")
        # 获取文件路径
        v_rgb = cv2.VideoCapture(os.path.join(mp4_rgb, file))
        v_nir = cv2.VideoCapture(os.path.join(mp4_nir, file.replace("CCD", "NIR")))

        if v_rgb.isOpened() == False or v_nir.isOpened() == False:
            print("*" * 20, "waring!", "*" * 20, "file not found!")
            continue
        print("\nv_rgb path is :", os.path.join(mp4_rgb, file), "  The v_rgb video is opend:", v_rgb.isOpened())
        print("v_nir path is :", os.path.join(mp4_nir, file.replace("CCD", "NIR")), "  The v_nir video is opend:",v_nir.isOpened())

        # 获取第一个v_rgb视频的参数，保证红外和可见光视频fps、分辨率一致。程序自动适应不同总的帧数进行合并
        fps = v_rgb.get(cv2.CAP_PROP_FPS)
        w = v_rgb.get(cv2.CAP_PROP_FRAME_WIDTH)
        h = v_rgb.get(cv2.CAP_PROP_FRAME_HEIGHT)

        # fps = 15
        # w = 1920
        # h = 1080

        totalframes_ccd = int(v_rgb.get(cv2.CAP_PROP_FRAME_COUNT))
        totalframes_nir = int(v_nir.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_dist = totalframes_ccd - 5

        print('The v_rgb video w: {}, h: {}, totalframes: {}, fps: {}'.format(w, h, totalframes_ccd, fps))

        # 准备保存视频的参数 如果保存的是mage 宽度设置为3*w 如果保存的是处理后的图片 宽度设置为w
        cv2.namedWindow("windows", 0)
        out_video = cv2.VideoWriter(os.path.join(mp4_des, file.replace("CCD", "CCD-NIR")), fourcc, fps,
                                   (int(w), int(h)), True)
        out_mage = cv2.VideoWriter(os.path.join(mp4_des, file.replace("CCD", "CCD-NIR")), fourcc, fps,
                                   (int(3*w), int(h)), True)
        mage = np.zeros((int(h), int(3 * w), 3), np.uint8)
        m, status = cv2.findHomography(pts_nir, pts_rgb)

        i = 0
        while (frame_dist - i):
            rval_rgb, frame_rgb = v_rgb.read()
            rval_nir, frame_nir = v_nir.read()
            if rval_nir == False or rval_rgb == False:
                print("frame not found!,continue!")
                continue
            # print("rval_rgb is :", rval_rgb, "    frame_rgb is ", frame_rgb[0, 0], "    frame_rgb.shape is ",
            #       frame_rgb.shape)
            # print("rval_nir is :", rval_nir, "    frame_nir is ", frame_nir[0, 0], "    frame_nir.shape is ",
            #       frame_nir.shape)

            # # 将红外单通道转换成三通道
            # frame_nir = cv2.cvtColor(frame_nir, cv2.COLOR_GRAY2BGR)
            frame_nir_duizun = cv2.warpPerspective(frame_nir, m, (1920, 1080))

            # # 将红外单通道转换为伪彩色
            # frame_nir_duizun = cv2.applyColorMap(frame_nir_duizun, cv2.COLORMAP_JET)

            # # 将红外单通道转换为红色
            frame_nir_duizun[:, :, 0] = 0
            frame_nir_duizun[:, :, 1] = 0

            # frame_ronghe = frame_rgb * ronghelv + frame_nir_duizun * (1 - ronghelv)
            frame_ronghe = cv2.add(frame_rgb, frame_nir_duizun)

            # # 判断RBG的帧和融合后的帧是否相同，相同则说明红外帧为空
            # difference = cv2.subtract(frame_ronghe, frame_rgb)
            # result = not np.any(difference)
            # if result is True:
            #     print("两张图片一样")
            # else:
            #     print("两张图片不一样")

            frame_ronghe = frame_ronghe.astype(np.uint8)

            mage[0:int(h), 0:int(w)] = frame_rgb
            mage[0:int(h), int(w):int(2 * w)] = frame_nir_duizun
            mage[0:int(h), int(2 * w):int(3 * w)] = frame_ronghe

            # 修改此处切换显示或者保存的图像 frame_ronghe/mage
            # out_file.write(frame_ronghe)
            out_mage.write(mage)
            # cv2.imshow("windows", mage)
            i += 1
            print("总进度：", j, "/", len(files), "   当前文件进度:", str(i), "/", frame_dist)
        print("the file saved in ", os.path.join(mp4_des, file.replace("CCD", "CCD-NIR")))
        # out_file.release()
        j += 1
        print("-----------------------------------------------------------" * 2)
