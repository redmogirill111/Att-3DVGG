import cv2
import numpy as np

# 分别在RGB、红外图片上面找一些位置严格匹配的点
pts_rgb = np.array([[195, 699], [1679, 762], [826, 341], [1016, 353], [964, 212], [178, 298], [1616, 195], [1177, 90]])
pts_nir = np.array([[247, 687], [1740, 759], [886, 331], [1078, 344], [1034, 202], [243, 284], [1688, 190], [1249, 79]])

rgb = cv2.imread('/media/thhicv/新加卷/dataset/红外和可见光的火焰数据集/融合配准素材/ccd.jpg')
nir = cv2.imread('/media/thhicv/新加卷/dataset/红外和可见光的火焰数据集/融合配准素材/nir.jpg',0)

H, W, C = rgb.shape
nirx3 = cv2.cvtColor(nir,cv2.COLOR_GRAY2BGR) # conver to 3 channel

# 显示出图片，用来确定特征点的坐标
cv2.namedWindow("rgb", 0)
cv2.imshow('rgb',rgb)
cv2.namedWindow("nir", 0)
cv2.imshow('nir',nir)
cv2.waitKey(0)


h1, status = cv2.findHomography(pts_rgb, pts_nir)
# M = cv2.getPerspectiveTransform(pts_rgb,pts_nir)
# print("变换矩阵M为：",M)

duizunrgb = cv2.warpPerspective(rgb,h1,(1920,1080))

cv2.namedWindow("duizunrgb", 0)
cv2.imshow('duizunrgb',duizunrgb)
cv2.waitKey(0)

# 设置图像的融合的权重
a = 0.5
ronghe = nirx3 * a + duizunrgb * (1 - a)
# ronghe = cv2.add(nirx3,duizunnir)

ronghe = ronghe.astype(np.uint8)
## 保存图像的融合的结果显示
# cv2.imwrite("ronghe.jpg", ronghe)
cv2.namedWindow("ronghe", 0)
cv2.imshow("ronghe", ronghe)

cv2.waitKey(0)
cv2.destroyAllWindows()